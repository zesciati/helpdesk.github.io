<html>
<link rel="stylesheet" href="ViewTiket.css" >
<head> 
</head>
    <body>
        <div>
            <center><h1>Our answer: </h1></center>
    <?php
    include_once("koneksi.php");

    $id = $_GET['id'];
    
    $result = mysqli_query($mysqli, "SELECT solusi FROM users  WHERE id=$id");

    while($user_keluhan = mysqli_fetch_array($result)) {
        echo '<div style=" font-size: 40px;">'.wordwrap($user_keluhan["solusi"],30,"<br>\n",TRUE)."</div>";
    }
?>
    <center><a href="datatiket.php">Kembali</a></center>
    </div>
    </body>
</html>
